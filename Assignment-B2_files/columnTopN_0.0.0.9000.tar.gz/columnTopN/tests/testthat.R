library(testthat)
library(columnTopN)

test_check("columnTopN")
